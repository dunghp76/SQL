#!/bin/bash
/usr/bin/php /var/www/vhosts/i-8acb7e78/daito/upnoki/ps_upload_noki.php export rakuten
now=$(date +"%m-%d-%Y %T")
echo "ps_export_noki_rakuten.sh has been run at $now"

